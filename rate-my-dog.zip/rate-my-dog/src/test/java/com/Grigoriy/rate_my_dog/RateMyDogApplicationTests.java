package com.Grigoriy.rate_my_dog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RateMyDogApplicationTests {

	@Test
	void contextLoads() {
	}

}
