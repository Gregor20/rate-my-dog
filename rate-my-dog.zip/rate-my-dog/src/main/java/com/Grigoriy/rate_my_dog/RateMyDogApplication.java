package com.Grigoriy.rate_my_dog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RateMyDogApplication {

	public static void main(String[] args) {
		SpringApplication.run(RateMyDogApplication.class, args);
	}

}
